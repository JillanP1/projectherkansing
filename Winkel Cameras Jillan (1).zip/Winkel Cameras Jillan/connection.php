<?php

    require 'check_if_added.php';

    // Maak een databaseverbinding
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "store";

    // Maak de verbinding
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Controleer de verbinding
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- De rest van je code -->
    </head>
    <body>
        <!-- De rest van je code -->
    </body>
</html>
