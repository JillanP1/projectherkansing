<?php
    session_start();
    require 'connection.php';
    if(!isset($_SESSION['email'])){
        header('location:index.php');
        exit();
    }

    // Securely get the form input values
    $old_password = md5(md5(mysqli_real_escape_string($conn, $_POST['oldPassword'])));
    $new_password = md5(md5(mysqli_real_escape_string($conn, $_POST['newPassword'])));
    $email = $_SESSION['email'];

    // Fetch the password from the database for the current user
    $password_from_database_query = "SELECT password FROM users WHERE email='$email'";
    $password_from_database_result = mysqli_query($conn, $password_from_database_query) or die(mysqli_error($conn));
    $row = mysqli_fetch_array($password_from_database_result);

    // Check if the old password matches the one in the database
    if ($row['password'] == $old_password) {
        // Update the password in the database
        $update_password_query = "UPDATE users SET password='$new_password' WHERE email='$email'";
        $update_password_result = mysqli_query($conn, $update_password_query) or die(mysqli_error($conn));
        echo "Your password has been updated.";
        ?>
        <meta http-equiv="refresh" content="3;url=products.php" />
        <?php
    } else {
        ?>
        <script>
            window.alert("Wrong password!!");
        </script>
        <meta http-equiv="refresh" content="1;url=settings.php" />
        <?php
    }
?>
