<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['email'])) {
    header('location: login.php');
    exit();
}

$user_id = $_SESSION['id'];

// Query to fetch user products
$user_products_query = "SELECT it.id, it.name, it.price FROM users_items ut INNER JOIN items it ON it.id = ut.item_id WHERE ut.user_id = ?";
$stmt = $conn->prepare($user_products_query);

if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_products_result = $stmt->get_result();

$no_of_user_products = $user_products_result->num_rows;
$sum = 0;
if ($no_of_user_products == 0) {
    echo '<script>window.alert("No items in the cart!!");</script>';
} else {
    while ($row = $user_products_result->fetch_assoc()) {
        $sum += $row['price'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" href="img/lifestyleStore.png" />
    <title>Lifestyle Store</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- latest compiled and minified CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- jquery library -->
    <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
    <!-- Latest compiled and minified javascript -->
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <!-- External CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
    <div>
        <?php require 'header.php'; ?>
        <br>
        <div class="container">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>Item Number</th><th>Item Name</th><th>Price</th><th></th>
                    </tr>
                    <?php 
                    $counter = 1;
                    $user_products_result->data_seek(0);  // Reset result pointer to the beginning
                    while ($row = $user_products_result->fetch_assoc()) {
                    ?>
                    <tr>
                        <th><?php echo $counter ?></th>
                        <th><?php echo htmlspecialchars($row['name']) ?></th>
                        <th><?php echo htmlspecialchars($row['price']) ?></th>
                        <th><a href='cart_remove.php?id=<?php echo htmlspecialchars($row['id']) ?>'>Remove</a></th>
                    </tr>
                    <?php $counter++; } ?>
                    <tr>
                        <th></th>
                        <th>Total</th>
                        <th>Rs <?php echo $sum; ?>/-</th>
                        <th><a href="success.php?id=<?php echo $user_id ?>" class="btn btn-primary">Confirm Order</a></th>
                    </tr>
                </tbody>
            </table>
        </div>
        <br><br><br><br><br><br><br><br><br><br>
        <footer class="footer">
           <div class="container">
               <center>
                   <p>&copy; Lifestyle Store. All Rights Reserved. | Contact Us: +91 90000 00000</p>
                   <p>This website is developed by Sajal Agrawal</p>
               </center>
           </div>
       </footer>
    </div>
</body>
</html>
