<?php
require 'connection.php';
session_start();

// Controleer of 'id' is ingesteld in de URL
if(isset($_GET['id'])) {
    $item_id = $_GET['id'];
    
    // Controleer of 'id' en 'id' zijn ingesteld in de sessie
    if(isset($_SESSION['id'])) {
        $user_id = $_SESSION['id'];
        
        // Voer de query uit om het item uit de winkelwagen te verwijderen
        $delete_query = "DELETE FROM users_items WHERE user_id='$user_id' AND item_id='$item_id'";
        $delete_query_result = mysqli_query($conn, $delete_query);
        
        // Controleer op fouten
        if(!$delete_query_result) {
            die("Error: " . mysqli_error($conn));
        }
        
        // Als alles goed is gegaan, ga terug naar cart.php
        header('location: cart.php');
        exit(); // Stop het uitvoeren van de rest van de code
    } else {
        // Als 'id' niet is ingesteld in de sessie, stuur de gebruiker naar de inlogpagina
        header('location: login.php');
        exit(); // Stop het uitvoeren van de rest van de code
    }
} else {
    // Als 'id' niet is ingesteld in de URL, stuur de gebruiker naar de winkelwagenpagina
    header('location: cart.php');
    exit(); // Stop het uitvoeren van de rest van de code
}
?>
