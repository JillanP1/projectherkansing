<?php
// Start de sessie
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Favicon -->
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <!-- Titel van de pagina -->
        <title>Project Jillan</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Inclusie van de nieuwste gecompileerde en geminimaliseerde CSS van Bootstrap -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jQuery bibliotheek -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Inclusie van de nieuwste gecompileerde en geminimaliseerde JavaScript van Bootstrap -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- Externe CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
           <?php
            // Inclusie van de header
            require 'header.php';
           ?>
           <!-- Banner afbeelding -->
           <div id="bannerImage">
               <div class="container">
                   <center>
                   <div id="bannerContent">
                       <h1>Klik hier voor de Cameras</h1>
                       <p>Nu 40% korting op de producten</p>
                       <!-- Shop Nu knop -->
                       <a href="products.php" class="btn btn-danger">Shop Nu</a>
                   </div>
                   </center>
               </div>
           </div>
           <div class="container">
               <div class="row">
                   <!-- Camera Thumbnail -->
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="products.php">
                                <img src="img/camera.jpg" alt="Camera">
                           </a>
                           <center>
                                <div class="caption">
                                        <p id="autoResize">Cameras</p>
                                        <p>Kies voor de beste Cameras.</p>
                                </div>
                           </center>
                       </div>
                   </div>
  
            <br><br> <br><br><br><br>
           <!-- Footer -->
           <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Contact us: plaisierjillan@gmail.com</p>
                   <p>Deze website is gemaakt door Jillan Plaisier</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>
<!-- Auteur: Jillan Plaisier -->
