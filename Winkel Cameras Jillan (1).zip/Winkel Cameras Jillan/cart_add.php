<?php
require 'connection.php';
//require 'header.php';
session_start();

// Controleer of 'id' is ingesteld in de URL
if(isset($_GET['id'])) {
    $item_id = $_GET['id'];
    
    // Controleer of 'id' en 'id' zijn ingesteld in de sessie
    if(isset($_SESSION['id'])) {
        $user_id = $_SESSION['id'];
        
        // Voer de query uit om het item toe te voegen aan de winkelwagen
        $add_to_cart_query = "INSERT INTO users_items (user_id, item_id, status) VALUES ('$user_id', '$item_id', 'Added to cart')";
        $add_to_cart_result = mysqli_query($conn, $add_to_cart_query);
        
        // Controleer op fouten
        if(!$add_to_cart_result) {
            die("Error: " . mysqli_error($conn));
        }
        
        // Als alles goed is gegaan, ga terug naar products.php
        header('location: products.php');
        exit(); // Stop het uitvoeren van de rest van de code
    } else {
        // Als 'id' niet is ingesteld in de sessie, stuur de gebruiker naar de inlogpagina
        header('location: login.php');
        exit(); // Stop het uitvoeren van de rest van de code
    }
} else {
    // Als 'id' niet is ingesteld in de URL, stuur de gebruiker naar de productpagina
    header('location: products.php');
    exit(); // Stop het uitvoeren van de rest van de code
}
?>
